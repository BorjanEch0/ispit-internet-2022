"use strict";

const express = require('express');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const cors = require('cors');
const api = express();

const sql = require("./db");

api.use(cors())
api.use(bodyParser.json())

// Adding Basic Middlewares
api.use(helmet());
api.use(bodyParser.json());
api.use(bodyParser.urlencoded({ extended: false }));

const Reservations = function (reservation) {
    this.res_name = reservation.res_name;
    this.phone = reservation.phone;
    this.email = reservation.email;
    this.number_people = reservation.number_people;
    this.date = reservation.date;
    this.time = reservation.time;
    this.status = reservation.status;
};

Reservations.create = (newReservation, result) => {
    sql.query("INSERT INTO reservations SET ?", newReservation, (err, res) => {
        if (err) {
            console.log("Error: ", err);
            result(err, null);
            return;
        }

        console.log("Created reservation: ", { id: res.insertId, ...newReservation });
        result(null, { id: res.insertId, ...newReservation });
    });
};

Reservations.findAll = result => {
    sql.query("SELECT * FROM reservations", (err, res) => {
        if (err) {
            console.log("Error: ", err);
            result(null, err);
            return;
        }

        console.log("Reservations: ", res);
        result(null, res);
    });
};

Reservations.delete = (id, result) => {
    sql.query("DELETE FROM reservations WHERE id_reservation = ?", id, (err, res) => {
        if (err) {
            console.log("Error: ", err);
            result(null, err);
            return;
        }

        if (res.affectedRows == 0) {
            // Not found Reservation with the id
            result({ kind: "not_found"}, null);
            return;
        }

        console.log("Deleted reservation with id: ", id);
        result(null, res);
    });
};

Reservations.findById = (id, result) => {
    sql.query(`SELECT * FROM reservations WHERE id_reservation = ${id}`, (err, res) => {
        if (err) {
            console.log("Error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            console.log("Found reservation: ", res[0]);
            result(null, res[0]);
            return;
        }

        // Not found Reservation with the id
        result({ kind: "not_found" }, null);
    });
};

Reservations.updateById = (id, reservation, result) => {
    sql.query(
        "UPDATE reservations SET res_name = ?, phone = ?, email = ?, number_people = ?, date = ?, time = ?, status = ? WHERE id_reservation = ?",
        [reservation.res_name, reservation.phone, reservation.email, reservation.number_people, reservation.date, reservation.time, reservation.status, id],
        (err, res) => {
            if (err) {
                console.log("Error: ", err);
                result(null, err);
                return;
            }

            if (res.affectedRows == 0) {
                // Not found Reservation with the id
                result({ kind: "not_found" }, null);
                return;
            }

            console.log("Updated reservation: ", { id: id, ...reservation });
            result(null, { id: id, ...reservation });
        }
    );
};

api.post('/', (req, res) => {
    if (!Object.prototype.hasOwnProperty.call(req.body, "res_name") || req.body.res_name == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a reservation name property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "phone") || req.body.phone == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a phone property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "email") || req.body.email == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain an email property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "number_people") || req.body.number_people == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a number_people property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "date") || req.body.date == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a date property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "time") || req.body.time == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a time property",
        });
    }

    const reservation = new Reservations({
        res_name: req.body.res_name,
        phone: req.body.phone,
        email: req.body.email,
        number_people: req.body.number_people,
        date: req.body.date,
        time: req.body.time,
        status: 1,
    });

    Reservations.create(reservation, (err, data) => {
        if (err) {
            res.status(500).json({
                error: "Internal Server Error",
                message: err.message || "Some error occurred while creating the reservation.",
            });
        } else {
            res.status(201).json(data);
        }
    });
});

api.get('/', (req, res) => {
    Reservations.findAll((err, data) => {
        if (err) {
            res.status(500).json({
                error: "Internal Server Error",
                message: err.message || "Some error occurred while retrieving reservations.",
            });
        } else {
            res.status(200).json(data);
        }
    });
});

api.get('/:id', (req, res) => {
    Reservations.findById(req.params.id, (err, data) => {
        if (err) {
            res.status(500).json({
                error: "Internal Server Error",
                message: err.message || `Some error occurred while retrieving reservation ${req.params.id}.`,
            });
        } else {
            res.status(200).json(data);
        }
    });
});

api.delete('/:id', (req, res) => {
    Reservations.delete(req.params.id, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).json({
                    error: "Not Found",
                    message: `Not found reservation with id ${req.params.id}.`,
                });
            } else {
                res.status(500).json({
                    error: "Internal Server Error",
                    message: "Could not delete reservation with id " + req.params.id,
                });
            }
        } else {
            res.status(200).json(data);
        }
    });
});

api.put('/:id', (req, res) => {
    if (!Object.prototype.hasOwnProperty.call(req.body, "res_name") || req.body.res_name == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a reservation name property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "phone") || req.body.phone == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a phone property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "email") || req.body.email == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain an email property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "number_people") || req.body.number_people == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a number_people property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "date") || req.body.date == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a date property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "time") || req.body.time == "") {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a time property",
        });
    }

    if (!Object.prototype.hasOwnProperty.call(req.body, "status")) {
        return res.status(400).json({
            error: "Bad Request",
            message: "The request body must contain a status property",
        });
    }

    const reservation = new Reservations({
        res_name: req.body.res_name,
        phone: req.body.phone,
        email: req.body.email,
        number_people: req.body.number_people,
        date: req.body.date,
        time: req.body.time,
        status: req.body.status,
    });

    Reservations.updateById(req.params.id, reservation, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).json({
                    error: "Not Found",
                    message: `Not found reservation with id ${req.params.id}.`,
                });
            } else {
                res.status(500).json({
                    error: "Internal Server Error",
                    message: "Error updating reservation with id " + req.params.id,
                });
            }
        } else {
            res.status(200).json(data);
        }
    });
});


module.exports = api;
