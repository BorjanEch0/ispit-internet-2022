"use strict";

// Configuration variables
const port = process.env.PORT || "4000";

const HOST = process.env.HOST || "localhost";
const USER = "root";
const PASSWORD = "admin";
const DB = "restaurant";

module.exports = {
    port,
    HOST,
    USER,
    PASSWORD,
    DB,
};
