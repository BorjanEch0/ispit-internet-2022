create database restaurant;

use restaurant;

create table reservations(
    id_reservation int not null auto_increment primary key,
    res_name varchar(255) not null,
    phone varchar(255) not null,
    email varchar(255) not null,
    number_people int not null,
    date varchar(255) not null,
    time varchar(255) not null,
    status int not null
);